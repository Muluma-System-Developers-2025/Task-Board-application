# Task-Board-application
I built an application that keeps the team organized, logs all tasks automatically, and makes it easy to track what’s been done.
